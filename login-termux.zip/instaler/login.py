import os
os.system("clear")

#login

os.system("toilet -f smblock -F border:metal 'login'")

login = input("Password : ")
if login == "exe":
  os.system("clear")
  os.system("bash passt.sh")
  exit

else:
  os.system("clear")
  os.system("bash passf.sh")
  exit
