clear
echo -e "\e[0;32m"
echo "[+] Loading..."
sleep 2
echo -e "\e[0;32m"
echo "[+] Testing Password..."
sleep 2
echo -e "\e[0;32m"
echo "[+] Succesfully!"
sleep 2
echo -e "\e[0;32m"
echo "[+] Login..."
sleep 2
clear
echo -e "\e[0;32m"
echo "Login Succesfully!"
sleep 2
clear
exit
