clear
echo "[+] Deleting Bash.bashrc"
cd $HOME
cd ../usr/etc/
rm -f bash.bashrc
sleep 2
echo "[+] Succesfully"
sleep 1
echo "[+] Copying bash.bashrc"
cd $HOME
cd login-termux
cd instaler
cp bash.bashrc /data/data/com.termux/files/usr/etc
cp text.txt $HOME
cp passf.sh $HOME
cp passt.sh $HOME
cp login.py $HOME
sleep 3
clear
echo "Complete!"
exit
