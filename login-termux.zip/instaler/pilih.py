import os

#pilih
pilih = """
Pilih!
[1] Install
[0] Exit
"""
#input
print(pilih)

instal = input("Masukan Pilihan Anda!")
if instal == '1':
  os.system("sh 1.sh")
  exit

elif instal == '0':
  print("Terimakasih")
  exit

else:
  print ("Error")
