clear
python login.py
toilet -f smblock -F border:gay "Welcome To MYTOOL"
cat text.txt
echo ""
