#!/bin/sh
#ByFarhanEXE

clear
cd instaler
sh logbanner.sh
python pilih.py
exit
